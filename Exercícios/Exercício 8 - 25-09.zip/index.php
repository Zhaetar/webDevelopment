<html>

<head>
	<title>Exercícios</title>
	<link rel="stylesheet" type="text/css" href="Styles.css">
	<meta charset="UTF-8">
</head>

<body>
	<div id="indexContainer">
		<div id="header">
			<h1>Exercícios: Matheus Patrick</h1>
		</div>
		<div id="indexContent">
			<div class="button" onclick="location.href='Basic.php';">
				<h1>BÁSICO</h1>
				<p>Exercício 8</p>
			</div>
		</div>
	</div>
</body>

</html>